# Copyright (C) 2015 Yan Wang (yan.wang@ligo.org)
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2 of the License, or (at your
# option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
# Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.



#
# ======================================================================
#
#         Unit test for the SPIIR template bank generation
#
# ======================================================================
#


import commands
import sys
import os
import unittest
import matplotlib.pyplot as plt
import re
import numpy
import scipy

import lalsimulation
from gstlal.cbc_template_iir import *

def ceil_pow_2(x):
	x = int(math.ceil(x))
	x -= 1
	n = 1
	while n and (x & (x+1)):
		x |= x >> n
		n <<= 1
	return x + 1


class UnitTest01(unittest.TestCase):

	def testIIRBankGeneration(self):
		"""
		IIR bank generation test
			"""

		print '+++ make sure reference_psd.xml.gz and H1-GSTLAL_SPLIT_BANK_0000-0-0.xml.gz are in the current foler\n'
		print '------ testing IIR bank generation ------'
		cmd = '''
			gstlal_iir_bank --reference-psd reference_psd.xml.gz --padding 1.3 --downsample  --epsilon 0.02 --flow 30.0 --template-bank H1-GSTLAL_SPLIT_BANK_0000-0-0.xml.gz --instrument H1 --output iir_H1-GSTLAL_SPLIT_BANK_0000-0-0.xml.gz --sampleRate 4096.0 --verbose
				'''
		#status=0
		status = os.system(cmd.strip())
		self.failUnless(status==0)

	def testOverlap(self):
		"""
		Test the overlap between the summed-IIR reponse and the original templates
			"""

		print '+++ make sure you can directly use "ligolw_print"\n'
		print '----- testing if the overlaps for these low-mass templates are above 0.99 ------\n'

		cmd = '''
			ligolw_print -a matches iir_H1-GSTLAL_SPLIT_BANK_0000-0-0.xml.gz 
				'''
		status, output = commands.getstatusoutput(cmd.strip())
		assert status==0
		
		cmd2 = '''
			ligolw_print -t sngl_inspiral -c mchirp iir_H1-GSTLAL_SPLIT_BANK_0000-0-0.xml.gz 
				'''
		status2, output2 = commands.getstatusoutput(cmd2.strip())
		assert status2==0
		
		overlap = [float(xx) for xx in output.strip().split('\n') if xx.lstrip('0.').isdigit()]
		mchirp = [float(xx) for xx in output2.strip().split('\n') if xx.lstrip('0.').isdigit()]

		fig, ax = plt.subplots( nrows=1, ncols=1 )
		ax.plot(mchirp, overlap, 'o')
		plt.xlabel('Chirp mass')
		plt.ylabel('Overlap')
		fig.savefig('overlap.png')
		plt.close(fig)
		print 'Figure saved to overlap.png'

		self.failUnless(min(output)>=0.99)

	def testWaveform(self, flower=30., sampleRate=4096., epsilon = 0.02, alpha = 0.99, beta = 0.25, padding = 1.3):
		"""
			Test the SPIIR waveform
			"""
		
		m1 = 1
		m2 = 2
		spin1z = 0.1
		spin2z = 0.2

		print '------ Test the SPIIR waveform ------'
		print 'mass1 = %1.4f, mass2 = %1.4f, spin1z = %1.4f, spin2z = %1.4f' % (m1, m2, spin1z, spin2z)

		tchirp = lalsimulation.SimInspiralChirpTimeBound(flower, 
										m1 * lal.MSUN_SI, m2 * lal.MSUN_SI, 0., 0.)
		working_f_low_extra_time = .1 * tchirp + 1.0
		length_max = working_f_low_extra_time * 10 * sampleRate

		working_length = ceil_pow_2(length_max + round((32.0 + working_f_low_extra_time) * sampleRate))
		working_duration = float(working_length) / sampleRate

		amp, phase = gen_whitened_amp_phase(None, m1, m2, sampleRate, flower, 0, working_length, working_duration, length_max, 0, 0, spin1z, 0, 0, spin2z )
		a1, b0, delay = spawaveform.iir(amp, phase, epsilon, alpha, beta, padding, 1)
		length = amp.shape[0]
		u = spawaveform.iirresponse(length, a1, b0, delay)
		u_rev = u[::-1]
		norm_u = numpy.sqrt(abs(numpy.dot(u_rev,numpy.conj(u_rev))))
		u_rev *= numpy.sqrt(2)/norm_u

		wave_origin = amp*numpy.cos(phase)
		norm_wave = numpy.sqrt(numpy.dot(wave_origin, wave_origin))
		wave_origin /= norm_wave

		t_plot = numpy.arange(len(amp))/sampleRate
		fig, ax = plt.subplots( nrows=1, ncols=1 )

		index = -200
		ax.plot(t_plot[index:], wave_origin[index:], 'b', t_plot[index:], u_rev.real[index:], 'r--')
		plt.xlabel('time')
		plt.ylabel('relative amplitude')
		plt.title('Part of the original template (blue) and SPIIR approximate (red)')
		fig.savefig('waveform.png')
		plt.close(fig)
		print 'Figure saved to waveform.png'
		self.failUnless(True)

def make_suite():
	suite = unittest.TestSuite()
	suite.addTest(unittest.makeSuite(UnitTest01))
	return suite

def main():
	suite = make_suite()
	runner = unittest.TextTestRunner()
	runner.run(suite)


if __name__ == '__main__':
	main()


